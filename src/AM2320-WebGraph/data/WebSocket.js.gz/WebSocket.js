var connection = new WebSocket('ws://'+location.hostname+':81/', ['arduino']);
var thermoHygroGraph;
var maxDisplayNum = 100;
connection.onopen = function () {
    // Create THERMO/HYGRO Graph
    createGraph();

    // Return connection completion.
    var dt = new Date();
    var year = dt.getFullYear();
    var month = dt.getMonth() + 1;
    var day = dt.getDate();
    var hour = dt.getHours();
    var minute = dt.getMinutes();
    var second = dt.getSeconds();
    connection.send('Connect ' + year + ',' + month + ',' + day + ',' + hour + ',' + minute + ',' + second);
};
connection.onerror = function (error) {
    console.log('WebSocket Error ', error);
};
connection.onmessage = function (e) {
    var data_json = JSON.parse(e.data);
    console.log('Time: ' + data_json.time + ', THERMOMETER: ' + data_json.thermo + ', HYGROMETER: ' + data_json.hygro);
    document.getElementById("thermo").innerHTML = data_json.thermo;
    document.getElementById("hygro").innerHTML = data_json.hygro;

    // Update THERMO/HYGRO Graph
    if(!thermoHygroGraph) createGraph();
    var dt = new Date(data_json.time);
    var data = [parseInt(data_json.thermo),parseInt(data_json.hygro)];
    addData(thermoHygroGraph, dt, data);
};
connection.onclose = function(){
    console.log('WebSocket connection closed');
};

// Create THERMO/HYGRO Graph
function createGraph(){
    console.log('Create THERMO/HYGRO Graph');
    var ctx = document.getElementById("thermo-hygro-graph");
    thermoHygroGraph = new Chart(ctx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [
                {
                    label: 'THERMOMETER[' + String.fromCharCode(0xB0,0x43) + ']', // add ℃
                    data: [],
                    borderColor: "rgba(255,0,0,1)",
                    backgroundColor: "rgba(0,0,0,0)"
                },
                {
                    label: 'HYGROMETER[' + String.fromCharCode(0x25) + ']', // add %
                    data: [],
                    borderColor: "rgba(0,0,255,1)",
                    backgroundColor: "rgba(0,0,0,0)"
                }
            ],
        },
        options: {
            title: {
              display: true,
              text: 'THERMO/HYGRO METER Graph'
            },
            scales: {
                xAxes: [{
                    type: 'time',
                    time: {
                        tooltipFormat: 'YYYY/MM/DD HH:mm:ss',
                        displayFormats: {
                            millisecond:    'HH:mm:ss',
                            second:         'HH:mm:ss',
                            minute:         'HH:mm',
                            hour:           'M/D h:mm',
                            day:            'M/D',
                            week:           'M/D',
                            month:          'YYYY/M/D',
                            quarter:        'YYYY/M/D',
                            year:           'YYYY/M/D'
                        }
                    },
                    scaleLabel: {
                        display: true,
                    },
                    ticks: { 
                        autoSkip: true,
                    }
                }],
                yAxes: [{
                    scaleLabel: {
                        display: true,
                    },
                    ticks: {
                        beginAtZero:true
                    }
                }]
            },
            tooltips: {
                callbacks: {
                    label: function(tooltipItem, data) {
                        if(tooltipItem.datasetIndex === 0){
                            return 'THERMOMETER: ' + tooltipItem.yLabel + String.fromCharCode(0xB0,0x43); // add ℃
                        }else if(tooltipItem.datasetIndex === 1){
                            return 'HYGROMETER: ' + tooltipItem.yLabel + String.fromCharCode(0x25); // add %
                        }
                    },
                }
            },
        }
    });
}

function addData(chart, label, data) {
    chart.data.labels.push(label);
    if(chart.data.labels.length > maxDisplayNum) chart.data.labels.shift();
    data.forEach(function (value, index) {
        chart.data.datasets[index].data.push(value);
        if(chart.data.datasets[index].data.length > maxDisplayNum) chart.data.datasets[index].data.shift();
    });
    chart.update();
}

function resetGraph(){
    console.log('Reset THERMO/HYGRO Graph');
    if(thermoHygroGraph) thermoHygroGraph.destroy();
    createGraph();
}

function setInterval(radio) {
    if(!thermoHygroGraph) createGraph();
    console.log('Set mesure interval: ' + radio.value + 'seconds');
    connection.send('#' + radio.value);
}
